#include<bits/stdc++.h>
using namespace std;
int main()
{  ios_base::sync_with_stdio(false);
    cin.tie(NULL);   
  long long t,i,j,len;
  cin>>t;
  while(t--)
  {  long long flag = 1;
     string s;
     cin>>s;
    // cout<<s<<endl;
     len = s.length();
     for(int i=0;i<len;i++)
     {  if(s[i]!='9')
         {  flag=0;break;}
     }
     
     if(flag)
     {  //cout<<"h";
        cout<<"1";
        for(i=0;i<len-1;i++)
           cout<<"0";
         cout<<"1"<<endl;
      }
      else
      { long long mid = len/2;
        bool leftsmaller = false;
        long long i = mid - 1;
        long long j = (len%2)?mid+1:mid;
        while(i>=0 && s[i]==s[j])
           i--,j++;
        if(i<0 || s[i]<s[j] )
          leftsmaller = true;
        while(i>=0)
        {
           s[j] = s[i];
           i--;j++;
           //cout<<s<<endl;
        }//end of while
        if(leftsmaller == true)
        {  int carry = 1;
           i = mid - 1;
           if(len%2)
           {  
                 int temp = s[mid]-48; 
                  temp = temp + carry;
                //cout<<temp<<endl;
               
               //
               carry = temp / 10;
               temp = temp%10;
               s[mid] = char((temp%10)+48);
               j =mid + 1;
               //cout<<s[mid]<<endl;
              
            }
            else
              j = mid;
            while(i>=0)
            { int temp = int(s[i]-48);
                  temp = temp + carry;
                   
               carry = temp / 10;
               temp = temp%10;
               s[i] = char((temp%10)+48);
               s[j++] = s[i--];
             }
         //s[len]='\0';
          
        }//end of leftsmaller
        cout<<s<<endl;
      }//end of else   
    }//end  of while
}//end of main
   
 
 
 