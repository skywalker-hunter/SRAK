import java.util.*;
class Palin2
{
	public static void main(String[] args)throws java.lang.Exception{
	
		Scanner in = new Scanner(System.in);
		int t = in.nextInt();
	
		while(t-->0){
			String str = in.next();
			
			int n = str.length();
			int[] arr = new int[n];
			
			for(int i=0;i<n;i++){
				arr[i] = Character.getNumericValue(str.charAt(i));
			}
			
			getNextPalindrome(arr, n);
			
			System.out.println();
		}
		
		
	}
	
	public static boolean all9s(int[] arr, int n){
		boolean result = true;
		for(int i=0;i<n;i++){
			if(arr[i] != 9)
				return false;
		}
		return true;
	}
	
	public static void printArr(int[] arr, int n){
		for(int i=0;i<n;i++)
			System.out.print(arr[i]);
	}
	
	public static void getNextPalindrome(int[] arr, int n){
		
		if(all9s(arr, n)== true){
			System.out.print(1);
			for(int i=1;i<n;i++)
				System.out.print(0);
			System.out.print(1);
			//System.out.println();
		}
		else{
			int mid = n/2;
			int i = mid - 1;
			int j;
			if(n%2 == 0)
				j = mid;
			else
				j = mid + 1;
			
			while(i>=0){
				if(arr[i] == arr[j]){
					i--;
					j++;
				}
				else
					break;
			}
	
			boolean isSmaller = false;
			
			if(i<0 || arr[i]<arr[j])
				isSmaller = true;
			
			if(isSmaller == true){
				int carry = 1;
				
				i = mid-1;
				if(n%2 == 0)
					j = mid;
				else
					j = mid + 1;
				
				if(n%2 == 1){
					arr[mid] = arr[mid]+carry;
					carry = arr[mid]/10;
					arr[mid] = arr[mid]%10;
				}
				
				while(i>=0){
					arr[i] = arr[i] + carry;
					carry = arr[i]/10;
					arr[i] = arr[i]%10;
					
					arr[j] = arr[i];
					j++;
					i--;
				}
			}
			
			else{
				i = mid-1;
				if(n%2 == 0)
					j = mid;
				else
					j = mid+1;
				
				while(i>=0){
					arr[j] = arr[i];
					j++;
					i--;
				}
			}
			
			printArr(arr, n);
		}
	}
} 
Comments 
