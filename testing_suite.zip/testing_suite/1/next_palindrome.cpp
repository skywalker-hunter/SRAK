
#include <stdio.h>
#include <string.h>

char a[1000005];
int check(char a[],int n)
{
	int i,j,cnt=0;
	for(i=0;i<n;i++)
	{
		if(a[i]!='9')
		{
		cnt=1;
		return 0;
	    }
	}
	return 1;
}
int check1(char a[],int n)
{
	int i,j,cnt=0;
	for(i=0;i<n;i++)
	{
		if(a[i]!='9')
		{
		cnt=1;
		return 1;
	    }
	}
	return 0;
}
int main()
{
	
	int i,n,c,j,j1,flag,k,t,carry;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%s",a);
		n=strlen(a);
	//	printf("phanijbn");
		if(n%4 == 3){
			
	//	printf("phani");
		if(check1(a,n))
		{
			a[0]='1';
			for(i=1;i<n;i++)
			a[i]='0';
			a[n]='1';
			a[n+1]='\0';
			printf("%s\n",a);
		}
		else
		{
			c=0;
			flag=0;
			for(i=0;i<n/2;i++)
			{
				
				if(a[i]>a[n-i-1])
					flag=1;
				else if(a[i]<a[n-i-1])
				flag=-1;
				a[n-i-1]=a[i];
			}
			if(flag==1)
			printf("%s\n",a);
			else if(flag==0||flag==-1)
			{
				if(n%2==1)
				j=n/2;
				else
				j=n/2-1;
				carry=0;
				
				
				for(i=j;i>=0;i--)
				{
					if(i==j)
					{
					if(a[j]=='9')
				{
				a[j]='0';
				carry=1;
			    }
			    else
			    {
			    	a[j]++;
			    	carry=0;
				}
			    }
				else if(carry==1)
					{
						if(a[i]=='9')
						{
							a[i]='0';
							carry=1;
						}
						else
						{
						a[i]++;
						carry=0;
					    }
					}
					else
						a[i]=a[i];
					a[n-i-1]=a[i];
				}
				printf("%s\n",a);
				}
				
				}
		}else{
		if(check(a,n))
		{
			a[0]='1';
			for(i=1;i<n;i++)
			a[i]='0';
			a[n]='1';
			a[n+1]='\0';
			printf("%s\n",a);
		}
		else
		{
			c=0;
			flag=0;
			for(i=0;i<n/2;i++)
			{
				
				if(a[i]>a[n-i-1])
					flag=1;
				else if(a[i]<a[n-i-1])
				flag=-1;
				a[n-i-1]=a[i];
			}
			if(flag==1)
			printf("%s\n",a);
			else if(flag==0||flag==-1)
			{
				if(n%2==1)
				j=n/2;
				else
				j=n/2-1;
				carry=0;
				
				
				for(i=j;i>=0;i--)
				{
					if(i==j)
					{
					if(a[j]=='9')
				{
				a[j]='0';
				carry=1;
			    }
			    else
			    {
			    	a[j]++;
			    	carry=0;
				}
			    }
				else if(carry==1)
					{
						if(a[i]=='9')
						{
							a[i]='0';
							carry=1;
						}
						else
						{
						a[i]++;
						carry=0;
					    }
					}
					else
						a[i]=a[i];
					a[n-i-1]=a[i];
				}
				printf("%s\n",a);
				}
				
				}
			}
		}
	return 0;
} 