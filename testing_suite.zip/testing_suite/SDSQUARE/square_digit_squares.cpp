//correct code

#include<iostream>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
using namespace std;
long long SQRT(long long a){
    float b=sqrt(a);
    a=b;
    if(b>a)
        a++;
    return a;
}
bool isPerfect(long long x){
    bool perfect=true;
    while(x>0){
        int d=x%10;
        x/=10;
        if(d!=1 &&d!=4 && d!=9&&d!=0){
            perfect=false;
                break;
        }
    }
    return perfect;
}
int main(){
    int t,Squares[100001]={0};
    bool per[100001];
    for(long long i=1;i<100001;i++){
            long long x=i*i;
            if(isPerfect(x)){
                Squares[i]++;
                per[i]=true;
            }
            else
                per[i]=false;
            Squares[i]+=Squares[i-1];
    }
    cin>>t;
    while(t--){
        long long a,b;
        cin>>a>>b;
        int ans=0;
        a=SQRT(a);
        b=sqrt(b);
        if(per[a])
            ans++;
        ans+=Squares[b]-Squares[a];
        cout<<ans<<endl;
    }
    return 0;
}
 
