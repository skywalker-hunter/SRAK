//incorrect code

import java.util.*;
import java.lang.*;
import java.io.*;
 
/* Name of the class has to be "Main" only if the class is public. */
class square_digit_squares
{
	public static void main (String[] args) throws java.lang.Exception
	{
		// your code goes here
		Scanner sc = new Scanner(System.in);
		long set[]  = new long[100001];
		set[0]=1;
		//int m=1;
		for(long i=1;i<=100000;i++){
		    boolean result = check(i*i);
		    if(result==true)
		        set[(int)i]=1;
            else
                set[(int)i]=0;
		}int t = sc.nextInt();
		while(t-->0){
		    long a = sc.nextLong();
		    long b = sc.nextLong();
		    long x = (long)(Math.sqrt(a));

			/**/
		    if(x*x<=a)
		        x++;
            //int r = (int)x;
	        long count=0;
	        while(x*x<=b && x<=100000){
	            count+=set[(int)x];
	            x++;
	        }System.out.println(count);
		}
	}static boolean check(long x){
	    while(x>0){
	        int r = (int)(x%10);
	        if(r!=0 && r!=1 && r!=4 &&r!=9)
	            return false;
            x/=10;
	    }return true;
	}
}
 
