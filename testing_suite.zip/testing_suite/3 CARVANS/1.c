    #include<stdio.h>
    #include<math.h>
    #include<string.h>
    int fastRead();
    int main()
    {
          int t,n,c1,count,max;
          t=fastRead();
          while(t>0)
          {
                    count=1;
                    n=fastRead();
                    c1=fastRead();
                    max=c1;
                    while(n>1)
                    {
                              c1=fastRead();
                              if(c1<=max) { count++; max=c1; }
                              n--;
                    }
                    printf("\n%d",count);
                    t--;
          }
          return 0;
    }
    int fastRead()
    {
        int input;
        char c=0;
        while (c<33) c=getchar_unlocked();
        input=0;
        while (c>33)
        {
              input=input*10+c-'0';
              c=getchar_unlocked();
        }
        return input;
    } 