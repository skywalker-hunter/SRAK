//correct code

#include<iostream>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define MOD 1000000007
using namespace std;
long long p(int n)
{
    if(n==0) return 1;
 
    if(n%2==0)
    {
               long long x=p(n/2);
               return (x*x)%MOD;
    }
    else
    {
               long long x=p(n/2);
               return (x*x*2)%MOD;
    }
 
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
              int n;
              cin>>n;
              int ans;
              if(n%2==0)
                        ans=(3*p(n/2)-2)%MOD;
              else
                        ans=(4*p((n-1)/2)-2)%MOD;
              cout<<ans<<endl;
    }
    return 0;
}
 
