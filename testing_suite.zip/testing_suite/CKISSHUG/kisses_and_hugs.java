//incorrect code

import java.util.Scanner;
 
class kisses_and_hugs {
 
	static long C = 1000000007;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		try {
			Scanner sc = new Scanner(System.in);
			int T = sc.nextInt();
			for(int i=1; i<=T; i++){
				long N = sc.nextLong();
				if(N%2==1){
					/**/
					long res = twopower((N+3)/2)-1;
					System.out.println(res);
				}
				else{
					long res = (twopower(N/2) + twopower((N+2)/2) - 2)%C;
					System.out.println(res);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static long twopower(long n){
		
		if(n==0)
			return 1;
		
		long a1 = twopower(n/2) % C;
		long res = (a1*a1)%C;
		if(n%2==1){
			res = (res * 2)%C;
		}
		return res;
	}
 
}
