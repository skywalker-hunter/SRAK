 
import java.util.Scanner;
 
/**
 *
 * @author Nishant
 */
class Inequality {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        demo d=new demo();
        d.run();
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        answers a=new answers(t);
        
        
        
       
        for(int ind=0;ind<t;ind++)
        {
            int l=sc.nextInt();
            if(l==1)l++;
            int r=sc.nextInt();
            a.setData(l,r,ind,d);
            //System.out.println(t);
            a.run();
        }
        
        for(int ind=0;ind<t;ind++)
            {
                System.out.println(answers.ans[ind]);
            }
        //System.out.println(no_of_factors(126));
    }
 
     static boolean isSquareFree(int n, double[] a) {
        for(int i=0;i<a.length&&i<n;i++)
        {
            
            if((double)n%a[i]==0)return false;
            //System.out.println(a[i]);
            
        }
        return true;
            
    }
 
     static boolean isPrime(int num) {
        if(num==1)return false;
        if(num==2)return true;
        if(num==3)return true;
        for(int i = 2; i<= Math.sqrt(num);i++){
        if (num % i == 0 ){
            return false;
        }
    }
    return true;
    }
 
     static int no_of_factors(int n) {
        int count=0;
        if(n==1)return 0;
        if(n==2)return 1;
        if(isPrime(n))return 1;
        for(int i=2;i<n;i++)
        {
            if(isPrime(i))
            {
                
                if(n%i==0){count++;}
            }
        }
        return count;
    }
 
    public static int sumoffactors(int n) {
        int sum=0;
        if(isPrime(n)) return n+1;
        else
        {
            for(int i=1;i<=n;i++)
            {
                if(n%i==0)sum=sum+i;
            }
        }
        return sum;
    }
    
}
class demo implements Runnable
{
    int n=1001;
    int a[]=new int[n];
    double s[]=new double[316];
    demo()
    {
        for(int i=1;i<a.length;i++)
            a[i]=i;
        for(int i=2,j=0;i<317;i++,j++)
        {
            
            s[j]=Math.pow(i, 2);
            //System.out.println(a[j]);
        }
        
                
    }
    @Override
    public void run() {
        for(int i=1;i<a.length;i++)
        {
            //System.out.println(""+a[i]+Inequality.sumoffactors(a[i]));
            if(Inequality.isSquareFree(a[i],s)&& Inequality.isPrime(Inequality.no_of_factors(Inequality.sumoffactors(a[i]))))
                a[i]=Inequality.sumoffactors(a[i]);
            else {a[i]=0;}
        }
    
    }
   
    
}
 class answers implements Runnable
    {
        static int ans[];
        int ind,l,r;
        demo d;
        answers(int t)
        {
            ans=new int[t];
        }
        void setData(int l,int r,int ind,demo d)
        {
            this.l=l;
            this.r=r;
            this.ind=ind;
            this.d=d;
        }
        @Override
        public void run() {
            for(int i=l;i<=r;i++)
            {
                ans[ind]=ans[ind]+d.a[i];
            }
        }
        
    }
 