//correct code

import java.io.*;
class palindrome {
	public static long MOD=1000_000_007;
	// returns a^n % MOD
	// exponentiation by squaring
	public static long fast_exp(long base, long exp) {
	    long res=1;
	    while(exp>0) {
	       if(exp%2==1) res=(res*base)%MOD;
	       base=(base*base)%MOD;
	       exp/=2;
	    }
	    return res%MOD;
	}
	public static long calc(int n)
	{
		// inv25 is the inverse residue of 25 modulo MOD:
		// 25 * inv25 % MOD = 1
		long inv25 = fast_exp(25, MOD-2);
		int k = (n+1)/2;
		long p26 = fast_exp(26,k); // 26^k % MOD
		long ans = 52 * (p26 - 1) % MOD * inv25 % MOD; // 52 * (26^k-1) / 25 % MOD
		if(n%2==1)
			ans = (ans + MOD - p26) % MOD; // subtract 26^k for odd n
		return ans;
	}
	public static void main(String[] args)throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
		int t;
		t=Integer.parseInt(br.readLine().trim());
		while(t-->0){
			int n=Integer.parseInt(br.readLine().trim());
			long ans = calc(n);
			pw.println(ans);
		}
		pw.flush();
		pw.close();
	}
} 
