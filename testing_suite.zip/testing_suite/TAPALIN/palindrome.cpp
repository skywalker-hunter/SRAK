//incorrect code

#include<iostream>
using namespace std;
#define p 1000000007
long long int power(long long int x, long long int y)
{
    long long int res = 1;
    x = x % p;
 
    while (y > 0)
    {
        if (y & 1)
        res = (res*x) % p;
        y = y>>1;
        x = (x*x) % p;  
    }
    return res;
}
int main()
{
	long long int i,j,k,l,o,m,n,sum,x;
	cin>>x;
	while(x--)
	{
		o=0;
		cin>>n;
	    if(n%2==1)
	    o=1;
	    n/=2;
	    sum=power(26,n);
	    sum-=1;
	    sum+=p;
	    sum%=p;
	    sum*=52;
	    sum%=p;
	   /**/ long long int y = power(25, p - 1)%p;
	    sum=((sum*y)%p);
	    if(o==1)
	    {
	    m=power(26,n+1);
	    sum+=m;
		}
		sum%=p;
	    cout<<sum<<endl;
	}
} 
