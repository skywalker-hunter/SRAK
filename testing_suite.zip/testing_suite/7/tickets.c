#include <stdio.h>
#include <string.h>
 
int main()
{
    int i,t,flag=0,len;
    char str[101],even,odd;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%s",str);
        if(strlen(str) == 1 || strlen(str) == 0){
            printf("NO\n");
        }else{
            if(str[0]==str[1])
            {
                printf("NO\n");
            }
            else if(str[0]!=str[1] && strlen(str)==2)
            {
                printf("YES\n");
            }
            else
            {
                even=str[0];
                odd=str[1];
                flag=0;
                len=strlen(str);
                for(i=0; i<len; i+=2)
                {
                    if(i==len-1 && str[i]!=even)
                    {
                        flag=1;
                        break;
                    }
                    else if(str[i]!=even && str[i+1]!=odd)
                    {
                        flag=1;
                        break;
                    }
                }
                if(flag==0)
                {
                    printf("YES\n");
                }
                else
                {
                    printf("NO\n");
                }
            }
        }
    }
    return 0;
} 