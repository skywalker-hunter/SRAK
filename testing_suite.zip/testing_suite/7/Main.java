import java.util.*;
import java.lang.*;
 
public class Main
{
 public static void main (String[] args) throws java.lang.Exception
 {
   Scanner k = new Scanner(System.in);
   int t = k.nextInt();
   
   for(int i = 0; i < t; i++){
     
     String S = k.next();
 
     char a = S.charAt(0);
     char b = S.charAt(1);
     
     boolean bool = true;
     int mid = S.length()/2;
     
     if(a != b){
       if(S.length()%2 == 0){
         for(int c = 2, d = S.length()-1; c <= mid; c+=2, d-=2){
           if((S.charAt(c) == a) && (S.charAt(c+1) == b) && (S.charAt(d) == b) && (S.charAt(d-1) ==a)){
            continue;
           }else{
             bool = false;
             System.out.println("NO");
             break;
           }
         }
       }else{
         for(int c = 2, d = S.length()-1; c <= mid; c+=2, d-=2){
           if((S.charAt(c) == a) && (S.charAt(c+1) == b) && (S.charAt(d) == a) && (S.charAt(d-1) == b)){
             continue;
           }else{
             bool = false;
             System.out.println("NO");
             break;
           }
         }
       }
     }else{
       bool = false;
       System.out.println("NO");
     }
    
     if(bool){
       System.out.println("YES");
     }
   }
 }
}