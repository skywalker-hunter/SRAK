#include <iostream>
#include <string>
using namespace std;
 
int main() {
    int t,flag,i;
    cin >> t;
    while(t--){
        string s;
        cin >> s;
        
        char a = s[0],b=s[1];
        if (a!=b){
            for (i=0,flag=0;i<s.length();i++){
                if (i%2 == 0) {
                    if (s[i] == a)
                        flag = 1;
                    else{
                        flag = 0;
                        break;
                    }
                }
                else{
                    if (s[i] == b)
                        flag = 1;
                    else{
                        flag = 0;
                        break;
                    }
                }
            }
            if (flag == 1)
                cout << "YES" << endl;
            else
                cout << "NO" << endl;
        }
        else{
            cout << "NO" << endl;
        }
    }
	return 0;
} 