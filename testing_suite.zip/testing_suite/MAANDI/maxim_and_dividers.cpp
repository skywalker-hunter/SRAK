//incorrect code

#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pp pair<long long,long long>
#define f first
#define s second
#define pb push_back
ll arr[200100];
map<string,vector<string> > mp;
ll chck (ll n)
{
    while (n)
    {
        if (n%10==4 || n%10==7)
            return 1;
        n/=10;
    }
    return 0;
}
int main()
{
    ll n,i,t,j,k,l,m;
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin>>t;
    while (t--)
    {
        cin>>n;
        k=sqrt(n);
        ll ans=0;
	/**/
        for (i=1;i<k;i++)
        {
            if (n%i)
                continue;
            ans+=chck(i);
            if (i!=n/i)
                ans+=chck(n/i);
        }
        cout<<ans<<'\n';
    }
 
    return 0;
}
 
