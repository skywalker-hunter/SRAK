//correct code

#include <stdio.h>
#include <math.h>
int main(void) {
	int t;
	scanf("%d",&t);
	while(t--){
	    long long int n,a,i,count,x,y,b;
	    count=0;
	    scanf("%lld",&n);
	    a=sqrt(n);
	 for(i=1;i<=a;i++){
	     if(n%i==0){
	       for(x=i;x!=0;x=x/10){
	           if(x%10==4 || x%10==7){
	               count++;
	               break;
	           }
	       }
	       b=n/i;
	       if(b!=i){
	          for(y=b;y!=0;y=y/10){
	              if(y%10==4 || y%10==7){
	                  count++;
	               break;
	              }
	          } 
	       }
	         
	     }
	     
	 }
	 printf("%lld\n",count);    
    }
	return 0;
} 
