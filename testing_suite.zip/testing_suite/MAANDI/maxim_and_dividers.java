//correct code

import java.util.ArrayList;
import java.util.Scanner;
 
class MAANDI {
 
	 public static void main(String [] args){
		 try {
			
			 Scanner sc =new Scanner(System.in);
			 int T = sc.nextInt();
			 for(int i=0; i<T; i++){
				 long N = sc.nextLong();
				 int overluckyFactors = getOverluckyFactors(N);
				 System.out.println(overluckyFactors);
			 }
			 
			 
		} catch (Exception e) {
		}
	 }
 
	private static int getOverluckyFactors(long n) throws Exception {
		
		int overluckyFactors = 0;
		if(n<4){
			return 0;
		}
		else if(n==4){
			return 1;
		}
		else{
		long sqrt = (long) Math.sqrt(n);
		for(long i=1; i<=sqrt; i++){
			if(n%i==0){
				boolean hasNumber4Or7 = hasTheNoAFourOrSeven(i);
				if(hasNumber4Or7)
					overluckyFactors+=1;
				long factor2 = n/i;
				if(i!=factor2){
				hasNumber4Or7 = hasTheNoAFourOrSeven(factor2);
				if(hasNumber4Or7)
					overluckyFactors+=1;
				}
			}
		}
		
		return overluckyFactors;
		}
	}
 
	private static boolean hasTheNoAFourOrSeven(long n) {
		boolean numberHasFourOrSeven = false;
		while(n>0){
			long digit = n%10;
			if(digit==4 || digit==7)
			{
				numberHasFourOrSeven = true;
				break;
			}
			n = n / 10;
		}
		return numberHasFourOrSeven;
	}
}
 
