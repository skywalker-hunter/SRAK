import java.util.*;
import java.io.*;
class walk{
	public static void main(String[] args) {
		FastReader in = new FastReader();
		int t = in.nextInt();
		while(t-->0){
			int N = in.nextInt();
			long[] W = new long[N];
			for(int i=0 ; i<N ; i++){
				W[i] = in.nextInt();
			}
			long max = 0;
			for(int i=0 ; i<N ; i++){
				if((W[i]+i) > max)max = W[i]+i ;
			}
			System.out.println(max);
		}
	}
	static class FastReader
    {
        BufferedReader br;
        StringTokenizer st;
 
        public FastReader()
        {
            br = new BufferedReader(new
                     InputStreamReader(System.in));
        }
 
        String next()
        {
            while (st == null || !st.hasMoreElements())
            {
                try
                {
                    st = new StringTokenizer(br.readLine());
                }
                catch (IOException  e)
                {
                    e.printStackTrace();
                }
            }
            return st.nextToken();
        }
 
        int nextInt()
        {
            return Integer.parseInt(next());
        }
 
        long nextLong()
        {
            return Long.parseLong(next());
        }
 
        double nextDouble()
        {
            return Double.parseDouble(next());
        }
 
        String nextLine()
        {
            String str = "";
            try
            {
                str = br.readLine();
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            return str;
        }
    }
} 