#include <iostream>
#include <vector>
using namespace std;
int main()
{
	int t,n,k,i,j,x,num,ans;
	cin >> t;
	for(i=0;i<t;i++)
	{
		vector <int> v;
		cin >> n;
		for(j=0;j<n;j++)
		{
			cin >> x;
			v.push_back(x);
		}
		num=v[n-1];
		num++;
		for(k=n-2;k>=0;k--)
		{
			if(num>=v[k])
				num++;
			else 
			{
				num=v[k];
				num++;
			}
		}
		if(num%5 ==0){
			cout << num << "\n";
		}else{
			cout << num-1 << "\n";
		}
	}
	return 0;
} 