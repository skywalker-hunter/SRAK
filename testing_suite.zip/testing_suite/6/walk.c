    #include<stdio.h>
 
 
    int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,i,max,pos,diff;
        scanf("%d",&n);max=n+1;pos=n;
       for(i=0;i<n;i++){
            int w;
            scanf("%d",&w);max--;
            if(w>max){diff=w-max;pos+=diff;max+=diff;}
        }
        printf("%d\n",pos);
 
 
        }
 
 
 
    return 0;
    }
 
 