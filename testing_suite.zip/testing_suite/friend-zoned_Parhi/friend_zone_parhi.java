//correct code

import java.io.*;

class friend_zone_parhi
{

    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public static void main(String args[]) throws IOException
    {

        int t = Integer.parseInt(br.readLine());

        for(int i=0;i<t;i++)
        {

            String k = br.readLine();
            int max=0,ctr=0;

            for(int j=0;j<k.length();j++)
            {
                char a = k.charAt(j);
                if(a=='a'||a=='e'||a=='i'||a=='o'||a=='u')
                {
                    ctr++;
                }
                else
                {
                    if(ctr>max)
                        max=ctr;
                    ctr=0;
                }
            }
            if(ctr>max)
                max=ctr;
            System.out.println(max);
        }
    }
}
 
