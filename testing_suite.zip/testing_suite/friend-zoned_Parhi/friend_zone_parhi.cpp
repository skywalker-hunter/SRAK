//incorrect code


#include<bits/stdc++.h>

using namespace std;

int main()
{
    long long t,len,i,maxlen;
    cin >> t;

    while(t--)
    {

        string s;
        cin >> s;
        i=0;maxlen=0;len=0;
        while(s[i])
        {

            if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u')
                len++;
            else
            {
                maxlen=max(maxlen,len);
                len=0;
            }   
            i++;
        }
        cout << maxlen << "\n";

    }
    return 0;
} 
