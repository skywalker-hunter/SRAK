//correct code

#include<stdio.h>
#include<stdlib.h>
#include<string.h>


int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        char s[100000];
        scanf("%s",s);
        int i,n;
        n=strlen(s);
        int max=0;
        for(i=0;i<n;i++)
        {
            if((s[i]=='a')||(s[i]=='e')||(s[i]=='i')||(s[i]=='o')||(s[i]=='u'))
            {
                int c=1;
                i++;
                if(i!=n)
                {
                while((s[i]=='a')||(s[i]=='e')||(s[i]=='i')||(s[i]=='o')||(s[i]=='u'))
                {
                    c++;
                    i++;
                }
                }
                if(c>max)
                max=c;  
            }
            
        }
        printf("%d\n",max);
    }
    return 0;
}  
