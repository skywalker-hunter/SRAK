//correct code

#include <bits/stdc++.h>
using namespace std;
 
int main() {
	int t ;
	cin >> t ;
	while(t--){
		string a , b ;
		cin >> a >> b ;
		int n = a.size();
		int m = b.size();
		
		if( n > m ){
			int j = 0 ;
			for( int i = 0 ; i < n ; i++ ){
				if( a[i] == b[j]){
					j++;
				}
			}
			if( j == m ){
				cout<<"YES"<<endl;
			}
			else{
				cout<<"NO"<<endl;
			}
		}
		else{
			int j = 0 ;
			for( int i = 0 ; i < m ; i++ ){
				if( b[i] == a[j]){
					j++;
				}
			}
			if( j == n){
				cout<<"YES"<<endl;
			}
			else{
				cout<<"NO"<<endl;
			}
		}
	}
	return 0;
} 
