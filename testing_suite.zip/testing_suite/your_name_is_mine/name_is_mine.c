//correct code

#include <stdio.h>
#include <string.h>
int main()
{
	int t;
	char C1[25010],C2[25010];
	scanf("%d",&t);
	while(t--)
	{
		int n1,n2,i,j,flag=0;
		
		scanf("%s",C1);
		scanf("%s",C2);
		n1=strlen(C1);
		n2=strlen(C2);
	
		if(n1<n2)
		{i=0;
			for(j=0;j<n2;j++)
			{
				if(C1[i]==C2[j])
				{
					i++;
				}
 
			}
			if(i==n1)
				flag=1;
		}
		else
		{j=0;
		for(i=0;i<n1;i++)
			{
				if(C2[j]==C1[i])
				{
					j++;
				}
 
			}
			if(j==n2)
				flag=1;
		}
		if(flag==1)
			printf("YES\n");
		else
			printf("NO\n");
		
	}
	return 0;
} 
