//incorrect code

import java.util.*;
import java.lang.*;
import java.io.*;
import java.math.*;

class name_is_mine
{
	public static boolean subsequence1(String x,String y)
	{
		int j=0;
		for(int i=0;i<x.length() && j<y.length();i++)
		{	
			if(x.charAt(i)==y.charAt(j))
			{
				j++;
			}
		}
		if(j==y.length())
			return true;
		else
			return false;
	
	}
	
	public  static void main(String[]aegs )	
	{	
		Scanner cin=new Scanner(System.in);
		int t=cin.nextInt();
		while(t-->0)
		{
			String s=cin.next();
			String s1=cin.next();	
			boolean n=true;
			//if(s.length()>=s1.length())
 			//	n=subsequence1(s,s1);
			//else
				n=subsequence1(s1,s);
			if(n==true)	
				System.out.println("YES");
			else
				System.out.println("NO");
		}
	}
}
 
