#include <stdio.h>
 
void quicksort(int arr[], int low, int high);
 
int main(void) {
 int T;
 scanf("%d",&T);
while(T>0){
 int n;
 int i = 0;
 scanf("%d",&n);
 int array[100000];
 /* load some random values long long into the array */
 for(i = 0; i < n; i++)
  scanf("%d",&array[i]); 
 
 
 
 quicksort(array, 0, (n - 1));
 
 /* prlong long int the `quicksorted' 
for(i=0;i<n;i++){
printf("%d ",array[i]);
}
printf("\n");*/
 
 int min=array[1]-array[0];
int z;
 for(i=1;i<n-1;i++)
    {
        z=array[i+1]-array[i];
        
        if(z<=min)
        {
            min=z;
        }
        
    }
    printf("%d\n",min);
T--;
}
 
 return 0;
}
 
/* sort everything inbetween `low' <-> `high' */
void quicksort(int arr[], int low, int high) {
 int i = low;
 int j = high;
 int y = 0;
 /* compare value */
 int z = arr[(low + high) / 2];
 
 /* partition */
 do {
  /* find member above ... */
  while(arr[i] < z) i++;
 
  /* find element below ... */
  while(arr[j] > z) j--;
 
  if(i <= j) {
   /* swap two elements */
   y = arr[i];
   arr[i] = arr[j]; 
   arr[j] = y;
   i++; 
   j--;
  }
 } while(i <= j);
 
 /* recurse */
 if(low < j) 
  quicksort(arr, low, j);
 
 if(i < high) 
  quicksort(arr, i, high); 
}