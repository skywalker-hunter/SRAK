    #include<stdio.h>
    #include<stdlib.h>
    int compare (const void * a, const void * b)
    {
      return ( *(int*)a - *(int*)b );
    }
    int scan()
    {
    int t=0;
    char c;
    c=getchar_unlocked();
    while(c<'0' || c>'9')
    c=getchar_unlocked();
    while(c>='0' && c<='9')
    {
    t=(t<<3)+(t<<1)+c-'0';
    c=getchar_unlocked();
    }
    return(t);
    }
    int main()
    {
        int t;
        t=scan();
        while(t--)
        {
            int n,s[5010],i,j,min;
            n=scan();
            for(i=0;i<n;i++)
            {
                s[i]=scan();
            }
             qsort (s,n, sizeof(int), compare);
             min=s[1]-s[0];
             for(i=1;i<n-1;i++)
             {
                 if(s[i+1]-s[i]<min)
                 min=s[i+1]-s[i];
             }
            printf("%d\n",min);
            }
            return 0;
    } 