#include <stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,i,sum = 0,temp = 0;;
        scanf("%d",&n);
        int b[n];
        for(i=0;i<n;i++)
        {
            scanf("%d",&b[i]);
            sum = sum + b[i];
            temp = temp + b[i];
            if(b[i] != 0)
                temp = temp - 1;
        }
        if(temp<100 && sum >= 100)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}
 