import java.util.*;
import java.io.*;
 
class serejavotes{
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		PrintWriter out = new PrintWriter(System.out);
		int test = in.nextInt();
		while(test-->0){
			int n = in.nextInt();
			int[] b = new int[n];
			for(int i=0 ; i<n ; i++) b[i] = in.nextInt();
			int sum = 0;
		    int ct = 0;
			for(int i=0 ; i<n ; i++){
				sum += b[i];
				if(b[i] > 0)ct++;
			}
			if(sum == 100){
				out.println("YES");
				continue;
			}
			else if(sum < 100){
				out.println("NO");
				continue;
			}
			else if(sum-ct >= 100){
				out.println("NO");
			}
			else
			   out.println("YES");	
		}
		out.flush();
	}
} 