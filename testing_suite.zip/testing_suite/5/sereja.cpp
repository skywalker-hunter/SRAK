#include <bits/stdc++.h>
 
#define MAX 10000
 
using namespace std;
 
 
int main(){
	int t;
	cin>>t;
	while(t--){
        int n;
		cin>>n;
		int b[n];
		int sum=0,zeroes=0;
		for(int i=0;i<n;i++){
			cin>>b[i];
			if(b[i]==0)
				zeroes++;
			sum=sum+b[i];
		}
		n=n-zeroes;
		if(sum<100){
			cout<<"NO"<<endl;
		}else if(sum==100){
			cout<<"YES"<<endl;
		}else{
			if(0.9999*n >= sum-100)
				cout<<"YES"<<endl;
			else
				cout<<"NO"<<endl;
		}
	}
	return 0;
}
 