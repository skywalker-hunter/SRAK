//correct code

#include<bits/stdc++.h>
#include<stdio.h>
#include<math.h>

using namespace std;

int main()
{
    int limit,num,i,test;
    long long sum;

	scanf("%d",&test);

    while(test>0)
    {

        test--;
		scanf("%d",&num);
        sum=0;
        limit=sqrt(num);

        for(i=1;i<=limit;i++)
        {
            if((num%i==0)&&(num/i!=i))
                sum+=(num/i)+i;
            else if((num%i==0)&&(num/i==i))
                sum+=num/i;
        }

        printf("%lld\n",sum);

    }
    return 0;
}
 
