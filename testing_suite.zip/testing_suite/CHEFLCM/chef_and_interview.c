//correct code

#include<stdio.h>

int main()
{
    int t;
    scanf("%d",&t);

    while(t--)
    {

        long long int n,i,sum=0;
        scanf("%lld",&n);

        for(i=1;i*i<=n;i++)
        {
            if(n%i==0)
            {
                sum+=i;
            if(i!=n/i)
            {
                sum+=n/i;
            }
            }
        }
        printf("%lld\n",sum);

    }

    return 0;
} 
