//incorrect code

import java.util.ArrayList;
import java.util.Scanner;
 
class chef_and_interview{
 
	public static void main(String[] args) {
 
		try {
			Scanner sc = new Scanner(System.in);
			int T = sc.nextInt();
			for(int i=1; i<=T; i++){
				long N = sc.nextLong();
				ArrayList<Long>factors = getFactors(N);
				long sum = 0;
				for(int j=0; j<factors.size(); j++){
					sum += factors.get(j);
				}
				System.out.println(sum);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
 
	private static ArrayList<Long> getFactors(long n) {
		ArrayList<Long>factors = new ArrayList<>();
		
	/**/	
		for(long i=1; i<Math.sqrt(n); i++){
			if(n%i==0){
				if(!factors.contains(i))
					factors.add(i);
				
				long factor2 = n/i;
				if(!factors.contains(factor2)){
					factors.add(factor2);
				}
			}
		}
		
		return factors;
	}
 
}
 
