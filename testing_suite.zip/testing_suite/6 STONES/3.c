#include<stdio.h>
#include<string.h>
int main() 
{
    int t,i,k;
    scanf("%d",&t);
    while(t--)
    {
              int ctr=0;
              char j[151],s[151];
              scanf("%s",j);
              scanf("%s",s);
              for(i=0;i<strlen(s);i++)
              {
                  for(k=0;k<strlen(j);k++)
                  {
                       if(s[i]==j[k])
                       {
                           ctr++;
                           break;}}}
                           printf("%d\n",ctr*2);
              
              
              }
                                   return 0;
}