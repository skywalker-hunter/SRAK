#include <stdio.h>
#include <stdlib.h>
int main(){
    int t,n,x,i,j,r,m;
    long s;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d",&n,&x);
        m=10000;s=0;
        for(i=0;i<n;i++){
            scanf("%d",&j);
            s+=j;
            if(j<m) m=j;
        }
        r=s/x;
        if((s-r*x)>=m){
            printf("-1\n");
        }
        else printf("%d\n",r);
    }
    return 0;
}