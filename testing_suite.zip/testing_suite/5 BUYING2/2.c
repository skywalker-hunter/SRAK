#include<stdio.h>
int main()
{
int n,x;
int A[100];
int t,i,sum=0,flag=0;
scanf("%d",&t);
  while(t--)
    {   sum=0;flag=0;
	    scanf("%d %d",&n,&x);
	     for(i=0;i<n;i++)
	        {
	          scanf("%d",&A[i]);
	          sum+=A[i];
	        }
	 int rem=sum%x;
	 for(i=0;i<n;i++)
	 {  if((rem-A[i])>=0) {flag=1;break;}
	 }
	  if(flag==1) printf("\n-1");
	  else printf("\n%d",sum/x);
	 }
return 0;
}