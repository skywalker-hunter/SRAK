#include <stdio.h>
 
int main()
{
    int t, n, x;
    int value, sum;
    int min, i, j;
 
    scanf("%d", &t);
 
    for(i=0; i<t; i++)
    {
        scanf("%d %d", &n, &x);
        min=10000;
        sum=0;
 
        for(j=0; j<n; j++)
        {
            scanf("%d", &value);
            if(value<min)
                min=value;
            sum+=value;
        }
 
        if(((sum-min)/x) == (sum/x))
            printf("-1\n");
        else
            printf("%d\n", sum/x);
    }
    return 0;
}