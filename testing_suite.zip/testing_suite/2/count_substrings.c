#include <stdio.h>
    int main()
    {
        int t;
        scanf("%d",&t);
        while(t--)
        {
            long long int n,co=0,q,i;
            scanf("%lld",&n);
            char p;
            getchar();
            for(i=0;i<n;i++)
            {
                scanf("%c",&p);
                if(p=='1')
                    co++;
            }
            q=(co*(co+1))/2;
            printf("%lld\n",q);
        }
        return 0;
    }
       