#include <iostream>
using namespace std;
int main()
{
    long long int t,n;
    long long int c,x;
    string s;
    cin>>t;
    while(t--)
    {
        c=0;
        cin>>n;
        cin>>s;
        for(int i=0;i<n;i++)
        {
            if(s[i]=='1')
                c++;
        }
    x=(c*(c+1))/2;
    cout<<x<<endl;
    }
    return 0;
}
  