#include <stdio.h>
#include <string.h>
int main ()
{
    int t,l;
    scanf("%d",&t);
    for (l=0;l<t;++l)
    {
        int l,i,j,k,B[26]={0},C[26]={0};
        char A[1005];
        scanf("%s",A);
        l=strlen (A);
        k=l/2;
        for (i=0;i<k;++i)
        {
            j=A[i]-'a';
            B[j]++;
        }
        if (l%2==0)
            for (i=k;i<l;++i)
            {
                j=A[i]-'a';
                C[j]++;
            }
        else
            for (i=k+1;i<l;++i)
            {
                j=A[i]-'a';
                C[j]++;
            }
        k=0;
        for (i=0;i<26;++i)
            if (B[i]!=C[i])
                k=1;
        if (k==1)
            printf("NO\n");
        else
            printf("YES\n");
    }
    return (0);
}