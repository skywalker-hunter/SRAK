#include<stdio.h>
#include<string.h>
int main()
{ int s,t,i,a,f;
 char str[1001];
 static int abc[26];
 scanf("%d", &t);
 while(t--)
 { for(i=0;i<26;i++)
   {  if(abc)
      abc[i]=0;
    }
   f=0;
   scanf("%s", str);
   s=strlen(str);
 
   if(s%2==0)
    {
     for(i=0;i<s/2;i++)
     { a=str[i]-97;
       abc[a]++;
     }
     for(i=s/2;i<s;i++)
      { a=str[i]-97;
        abc[a]--;
      }
     for(i=0;i<26;i++)
     { if(abc[i]!=0)
      { f=1; break;}
     }
    }
   else
   { for(i=0;i<s/2;i++)
     { a=str[i]-97;
       abc[a]++;
     }
     for(i=(s/2)+1;i<s;i++)
      { a=str[i]-97;
        abc[a]--;
      }
     for(i=0;i<26;i++)
     { if(abc[i]!=0)
      { f=1; break;}
        else f=0;
     }
   }
   if(f==1)
    printf("NO\n");
   else
    printf("YES\n");
   fflush(stdin);
 }
  return 0;
}