    #include<stdio.h>
     
    int main()
    {
     
     int t,n,i,j;
     int counti,countl;
     int array[105];
     scanf("%d",&t);
     
     while(t--)
      {
        scanf("%d",&n);
        counti=0;
        countl=0;
     
        for(i=1;i<=n;i++)
          {
             scanf("%d",&array[i]);
          }
       
        
        for(i=1;i<n;i++)
          {
            for(j=i+1;j<=n;j++)
             {
               
            if(array[i]>array[j])
               {
                   counti++;
                 if(j==(i+1))
                   {
                     countl++;
                   }
                  
               }
     
     
             }
          } 
     
       if(counti==countl)
        { 
          printf("YES\n");
        }
       else
        {
          printf("NO\n");
        }
        
        
     
       }
    return 0;
    } 