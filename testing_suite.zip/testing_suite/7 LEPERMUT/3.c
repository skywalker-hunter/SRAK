    #include<stdio.h>
    #include<math.h>
    int main()
    {
    	int tc,n,a[100],c,cc,i,j;
    	scanf("%d",&tc);
    	while(tc--)
    	{
    c=0;cc=0;
    scanf("%d%d",&n,&a[0]);
    if(n==1)
    printf("YES\n");
    else
    {
    for(i=1;i<n;i++)
    {
    scanf("%d",&a[i]);
    if(a[i-1]>a[i])
    cc++;
    }
    for(i=0;i<n-1;i++)
    {
    	for(j=i+1;j<n;j++)
    	{
    		if(a[i]>a[j])
    			c++;
    	}
    }
    if(c==cc)
    printf("YES\n");
    else
    printf("NO\n");
    }
     
    	}
    return 0;
    } 