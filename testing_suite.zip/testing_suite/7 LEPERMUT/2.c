#include<stdio.h>
#define SIZE 100
int count;
void merge(int a[],int p,int q,int r)
{
	int i,L[SIZE],R[SIZE],x,y,k;
	int n1=q-p;
	int n2=r-q-1;
	for(i=0;i<=n1;i++)
		L[i]=a[p+i];
	for(i=0;i<=n2;i++)
		R[i]=a[q+i+1];
	x=y=0;
	k=p;
	L[n1+1]=100000;
	R[n2+1]=100000;
	while(k<=r)
	{
		if(L[x]<=R[y])
		{
			a[k]=L[x];
			x++;
			k++;
		}
		else
		{
			a[k]=R[y];
			y++;
			if(k<r)
				count = count + q-x-p+1;
			k++;
			
		}
	
	}
}
 
void mergesort(int a[],int p,int r)
{
		
	int q=(p+r)/2;
	if(p>=r)
		return;
	else
		{
			mergesort(a,p,q);
			mergesort(a,q+1,r);
			merge(a,p,q,r);
		}	
}
 
int main()
{
int t,a[SIZE],i,n,j,no_li;
scanf("%d",&t);
for(i=0;i<t;i++)
{
	no_li=0;
	count = 0;
	scanf("%d",&n);
		for(j=0;j<n;j++)
			scanf("%d",&a[j]);
	for(j=0;j<n-1;j++)
		if(a[j]>a[j+1])
			no_li++;
	mergesort(a,0,n-1);
	if (count == no_li)		
	printf("YES\n");
	else
	printf("no\n");
}
return 0;
}