#include<stdio.h>
int main()
{
int t,n,i,a[101],k,fav,j,pos;
scanf("%d",&t);
while(t--)
{
scanf("%d",&n);
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
scanf("%d",&k);
fav=a[k-1];
pos=0;
for(i=0;i<n;i++)
{
if(fav>a[i])
pos++;
}
printf("%d\n",pos+1);
}
return 0;
}  