    #include <stdio.h>
     
    void fastread(long long int *a)
    {
        char c=0;
        while(c<33)
        {
            c=getchar_unlocked();
        }
        *a=0;
        while(c>33){
            *a=*a*10+c-'0';
            c=getchar_unlocked();
        }
    }
     
     
    int main()
    {
        int t,n,k,i,count;
        long long int a[100];
        scanf("%d",&t);
      while(t--)
      {
          count=0;
          scanf("%d",&n);
          for(i=0;i<n;i++)
              fastread(&a[i]);
          scanf("%d",&k);
          for(i=0;i<n;i++)
          {
          if(a[i]<=a[k-1])
              count++;
          }
          printf("%d\n",count);
       }
     
        return 0;
    } 