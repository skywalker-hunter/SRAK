    #include<stdio.h>
    #define gchar getchar_unlocked()
    void scan_d(int *n)
    {
    register char c=0;
    while(c<33)
    c=gchar;
    *n=0;
    while(c>33)
    {
    	*n=*n*10+c-'0';
    	c=gchar;
    }
    }
     
    int main()
    {
    int t,n,i,j,pivot,temp,k,arr[100];
    scan_d(&t);
    while(t--)
    {
    	scan_d(&n);
    	for(i=0;i<n;i++)
    	scan_d(&arr[i]);;
    	scan_d(&k);
    	temp=arr[0];
    	arr[0]=arr[k-1];
    	arr[k-1]=temp;
    	pivot=0;
    	i=0;
    	j=n-1;
    	while(i<j){
            	while(arr[i]<=arr[pivot]&&i<n-1)
            	        i++;
            	while(arr[j]>arr[pivot])
            	        j--;
            	if(i<j){
            	        temp=arr[i];
            	        arr[i]=arr[j];
                    	arr[j]=temp;
            	}
    	}
    	printf("%d\n",j+1);
    }
    return 0;
    } 