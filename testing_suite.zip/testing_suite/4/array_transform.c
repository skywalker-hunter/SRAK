#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
 
int main() {
int t,i,j,k,a[110],min,ans1=-1,ans2,f,n;
    scanf("%d",&t);
while(t--)
{scanf("%d %d",&n,&k);
 min=11000;
 ans1=-1;
 for(i=1;i<=n;i++)
  {scanf("%d",&a[i]);
  if(a[i]<min)
      min=a[i];
  }
for(i=0;i<=k;i++)
{ans2=0;
  for(j=1;j<=n;j++)
  {f=a[j]-(min-i);
   if(f%(k+1)==0)
       ans2++;
  }
  if(ans2==n || ans2==n-1)
      ans1=1;
}    
 if(ans1==1)
     printf("YES\n");
 else
     printf("NO\n");
}    
  return 0;
}