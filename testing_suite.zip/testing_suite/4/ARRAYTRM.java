
import java.io.*;
import java.util.*;
class ARRAYTRM
{
    public static void main(String[] args)throws IOException
    {
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        int t=Integer.parseInt(br.readLine());
        while(t-->0)
        {
            String[] line1=br.readLine().split(" ");
            int num=Integer.parseInt(line1[0]);
            int k=Integer.parseInt(line1[1]);
 
            String[] line2=br.readLine().split(" ");
            int[] Ar=new int[num];
            HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
 
            for(int i=0;i<num;i++)
            {	Ar[i]=Integer.parseInt(line2[i]);
                int rem=Ar[i]%(k+1);
 
                if(hm.get(rem)!=null)
                    hm.put(rem,(hm.get(rem))+1);
                else
                    hm.put(rem,1);
            }
 
            Iterator<Integer> keySetIterator = hm.keySet().iterator();
            int count=0,max=0;
            while(keySetIterator.hasNext()){ Integer key = keySetIterator.next();
 
                count++;
                if(hm.get(key)>max)
                    max=hm.get(key);
 
                // System.out.println(key+" "+hm.get(key));
            }
 
            if(count<=2&&(max==num-1||max==num))
                System.out.println("YES");
            else
                System.out.println("NO");
 
 
 
 
        }
    }
} 