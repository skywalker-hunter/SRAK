#include<bits/stdc++.h>
using namespace std;
 
int t,n,k,x,a[1002],b[11];
 
int main()
{
	scanf("%i",&t);
	while(t--)
	{
		for(int i=0;i<1002;++i)
			a[i]=0;
		for(int i=0;i<11;++i)
			b[i]=0;
		scanf("%i%i",&n,&k);
		for(int i=0;i<n;++i)
		{
			scanf("%i",&x);
			a[x]++;
		}
		++k;
		bool lol=0;
		for(int i=0;i<1001;++i) 
			b[i%k] += a[i];
		for(int i=0;i<11;++i)
			if(b[i] > n-2)
			{
				lol=1;
				break;
			}
		if(lol)
			printf("YES\n");
		else
			printf("NO\n");
	}
}
  